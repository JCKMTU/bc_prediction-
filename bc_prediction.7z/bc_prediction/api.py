import json, requests, time

t = 3
URL = "https://coincheck.com"


class Coincheck:
    def __init__(self, url=URL):
        self.url = url

    def get_ticker(self):
        return requests.get(self.url + '/api/ticker').json()

    def get_trades(self):
        return requests.get(self.url + '/api/trades').json()

    def get_order_books(self):
        return requests.get(self.url + '/api/order_books').json()

    def get_rate(self):
        return requests.get(self.url + '/api/exchange/orders/rate').json()


def main():
    cc = Coincheck()

    while True:
        for key, item in cc.get_ticker().items():
            print("%-9s : %-10.9s " % (key, item))
        
        time.sleep(t)


if __name__ == '__main__':
    main()